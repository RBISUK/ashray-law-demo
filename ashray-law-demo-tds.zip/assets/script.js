// Year + mobile nav + form checks
const y = document.getElementById('year'); if (y) y.textContent = new Date().getFullYear();

const toggle = document.querySelector('.nav-toggle');
const nav = document.getElementById('site-nav');
if (toggle && nav) {
  toggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(open));
  });
}

function hookForm(id) {
  const form = document.getElementById(id);
  if (!form) return;
  form.addEventListener('submit', (e) => {
    const required = form.querySelectorAll('[required]');
    for (const el of required) {
      if (!el.value.trim()) { e.preventDefault(); alert('Please fill all required fields.'); return; }
    }
  });
}
hookForm('contact-form');
hookForm('tds-form');